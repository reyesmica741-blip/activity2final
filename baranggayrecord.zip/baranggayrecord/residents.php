
<?php
require_once "config.php";

$result = mysqli_query($conn, "SELECT * FROM residents");
$total = mysqli_num_rows($result);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Residents</title>

    <style>
        body {
            font-family: Arial;
            margin: 0;
            background: white;
        }

        nav {
            padding: 20px;
        }

        nav a {
            margin-right: 20px;
            text-decoration: none;
            color: black;
        }

        .container {
            padding: 20px;
        }

        .box {
            width: 280px;
            height: 70px;
            display: flex;
            justify-content: center;
            align-items: center;
            color: white;
            font-size: 20px;
            font-weight: bold;
            text-decoration: none;
            background: #198754;
        }
    </style>
</head>

<body>

<nav>
    <a href="dashboard.php">Dashboard</a>
    <a href="residents.php">Residents</a>
    <a href="officials.php">Officials</a>
    <a href="certificates.php">Certificates</a>
    <a href="logout.php">Logout</a>
</nav>

<div class="container">
    <h1>Residents</h1>
    <a href="residents.php" class="box">
        Total Residents: <?php echo $total; ?>
    </a>
</div>

</body>
</html>
