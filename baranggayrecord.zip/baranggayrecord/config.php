<?php
$conn = mysqli_connect("localhost", "root", "", "baranggayrecord");

if (!$conn) {
    die("Database connection failed: " . mysqli_connect_error());
}

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>