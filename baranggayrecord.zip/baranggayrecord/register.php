
<?php
require_once "config.php";

function h($str) {
    return htmlspecialchars($str ?? '', ENT_QUOTES, 'UTF-8');
}

$mess = [];
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === "POST") {

    $uname = trim($_POST['uname'] ?? '');
    $password = $_POST['password'] ?? '';
    $password2 = $_POST['password2'] ?? '';

    if (empty($uname) || empty($password)) {
        $errors[] = "Please complete all fields.";
    } elseif ($password !== $password2) {
        $errors[] = "Passwords do not match.";
    } elseif (strlen($password) < 8) {
        $errors[] = "Password must be at least 8 characters.";
    } else {

        $stmt = $conn->prepare(
            "SELECT id FROM users WHERE username = ?"
        );

        $stmt->bind_param("s", $uname);
        $stmt->execute();

        $result = $stmt->get_result();

        if ($result->num_rows > 0) {

            $errors[] = "Username already exists.";

        } else {

            $stmt->close();

            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

            $status = "pending";
            $role = "user";

            $stmt = $conn->prepare(
                "INSERT INTO users (username, password, status, role)
                 VALUES (?, ?, ?, ?)"
            );

            $stmt->bind_param(
                "ssss",
                $uname,
                $hashedPassword,
                $status,
                $role
            );

            if ($stmt->execute()) {
                $mess[] = "Registered successfully! Please wait for admin approval.";
            } else {
                $errors[] = "Registration failed. Please try again.";
            }
        }

        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
</head>

<body>

<h1>Management System</h1>
<h2>Create your Account</h2>

<?php foreach ($errors as $e): ?>
    <p style="color:red;"><?= h($e) ?></p>
<?php endforeach; ?>

<?php foreach ($mess as $m): ?>
    <p style="color:green;"><?= h($m) ?></p>
<?php endforeach; ?>

<form action="" method="POST">

    <label>Username:</label>
    <input type="text" name="uname"
        placeholder="Enter username" required>
    <br><br>

    <label>Password:</label>
    <input type="password" name="password"
        placeholder="Enter password" required>
    <br><br>

    <label>Re-enter password:</label>
    <input type="password" name="password2"
        placeholder="Confirm password" required>
    <br><br>

    <input type="submit" value="Register">

</form>

<p>Already have an account?
    <a href="index.php">Sign In</a>
</p>

</body>
</html>
